import React from 'react';

export default function SuccessPage() {
  return (
    <div className="continer">
      <div className="man">
        <img src="img/man.png" alt="Man" />
      </div>

      <div className="tite">   
        <h1>Votre numéro de téléphone a été mis à jour avec succès.</h1>
      </div>
    </div>
  );
}